/*
HumanTest.java
By: Russ Gleber 
*/

public class HumanTest{

	//main method
	public static void main(String[] args){
		System.out.println("Hello, Welcome to Niagara");
		//demonstrate constructor 2
		Human person1 = new Human(); //no name, 0
		//demonstrate constructor 2
		Human person2 = new Human(20); // no name, 20
		//demonstrate constructor 3
		Human person3 = new Human("John"); //John, 0
		//demonstrate constructor 4
		Human person4 = new Human("Mary",18); //Mary, 18
		//demonstrate constructor 5
		Human person5 = new Human(19,"Sam"); //Sam, 19

		System.out.println(person4.name);
		/*
		System.out.println(person4.age);
		*/
		System.out.println(person4.getAge());

		person4.greeting();

		System.out.println(Human.pi);
		/*
		person4.greeting_main();
		*/
		
		/*
		person1.greeting();
		person2.greeting();
		person3.greeting();
		person4.greeting();
		person5.greeting();
		*/

		/*
		Student s1 = new Student();
		Student s2 = new Student("Smith", "Computer Science", 21);

		s1.greeting();
		s2.greeting();

		Teacher t1 = new Teacher("Dr. Smith",31,"Assistant Professor"); //Teacher 1: Dr. Smith, 31, Assistant Professor
		Teacher t2 = new Teacher(); // Teacher 2: "no name", 0, "no title"
		Teacher t3 = new Teacher("Dr. Johnson", "Professor"); // Teacher 3: "Dr Johnson", 0, "Professor"		
		Teacher t4 = new Teacher("Professor", "Dr. Tim"); // Teacher 4: "Professor", 0, Dr. Tim

		t1.setTitle("Professor");
		t1.setName("Dr. Johnson II");
		t1.setAge(35);
		t1.greeting();
		t2.greeting();
		t3.greeting();
		t4.greeting();
		*/
	}
}