class Main {
  public static void main(String[] args) {
// calculate the area of a circle
  double circle_radius=10;
  double circle_area= Human.pi * circle_radius * circle_radius;
  System.out.println(circle_area);

  double a=10;
  double b=15;

  System.out.println("The larger value is "+Human.my_max2(a,b));
  }

}