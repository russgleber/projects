/*
Teacher.java
By: Russ Gleber
This is a child class of HumanTest.java
*/

public class Teacher extends Human {
	// properties, members, variables
	String title;

	// constructors
	public Teacher(){
		super();
		title="no-title";
	}

	public Teacher(String str_name, int age1, String str_title){
		super(str_name,age1);
		title=str_title;
	}

	public Teacher(String str_name, String str_title){
		super (str_name); //name=str_name, age=0
		title=str_title;
	}
	// methods
	// setters and getters | return value? parameters?

	// getter (get name) has a return value, but no parameters inside the parentheses (using this to pull name and age)
	public String getTitle(){
		return title;
	}

	// setter, has no return value, but does have parameters to set (use this to set values for the name and age)
	public void setTitle(String t){
		title = t;
	}

	public void greeting(){
		super.greeting();
		System.out.println("My title is " + title);
	}

}