# CIS259
# Homework 01
# By: Russ Gleber

#import math to use pi
import math

# Question 1
print("Question #1")
print("-----------")
print("The surface area of a sphere with radius r is 4πr2. What is the volume of a sphere with radius 15?")
pi=math.pi
r=15
volume_sphere=4/3*pi*r**3
print("The volume of a sphere with a radius of 15 is "+str(volume_sphere))
##############
print()
##############

# Question 2

print("Question #2")
print("-----------")
print("Write the formula to convert Fahrenheit (F) to Celsius (C) , and calculate what is the C for 98F?")
F=98
C=5/9*F-32
print ("98F is "+str(C)+"C")
##############
print()
##############

# Question 3

print("Question 3")
print("-----------")
print("What is the average of 10+20+30+50+80+100?")
sum=10+20+30+50+80+100
average=sum/6
print("The average is "+str(average))
##############
print()
##############
