public class StudentTest {
 	public static void main(String[] args) {
		//Define new student
    	Student student = new Student();
		//Student 1
    	Student student1 = new Student();
    	student1.setName("John");
    	student1.setGpa(3.68f);
		//Student 2
    	Student student2 = new Student();
    	student2.setName("Mary");
    	student2.setGpa(4.0f);
		//Student 3
		Student student3 = new Student();
    	student3.setName("Sam");
    	student3.setGpa(3.5f);
		//Student 4
		print_student(student1);
		print_student(student2);
		print_student(student3);
  	}
	//Print Result
  	public static void print_student(Student student) {
    	System.out.printf("The student %s has GPA = %s\n", student.getName(), student.getGpa());
  	}
}