public class Student{
	//Introduce Two Fields
 	private String name;
  	private float gpa;
	//Methods
  	public void setName(String _name){
	name = _name;
  	}

  	public void setGpa(float _gpa){
	gpa = _gpa;
  	}
 
  	public String getName(){
	return name;
  	}
 
  	public float getGpa(){
	return gpa;
  	}
}